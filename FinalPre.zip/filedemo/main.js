var fs = require('fs');

//blocking 
/*
var data = fs.readFileSync('input.txt');
console.log(data.toString());
*/

////--- non blocking 

fs.readFile('input.txt',function(err, data){
    console.log(data.toString());
});

console.log("Program Ended");